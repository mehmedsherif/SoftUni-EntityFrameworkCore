﻿namespace BookShop.Data
{
    internal class Configuration
    {
        internal static string ConnectionString
            => "Server=LAPTOP-642N6SM1\\MSSQLSERVER01;Database=BookShop;Integrated Security=True;";
    }
}
